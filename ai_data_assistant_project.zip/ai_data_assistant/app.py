# Entry point of the app (placeholder)
import streamlit as st
st.title("AI Data Assistant")
st.info("Please go to Home page to begin.")