import streamlit as st
from supabase_client import supabase

def login_signup():
    option = st.radio("Choose", ["Login", "Sign Up"])
    email = st.text_input("Email")
    password = st.text_input("Password", type="password")
    if option == "Login":
        if st.button("Login"):
            result = supabase.auth.sign_in_with_password({"email": email, "password": password})
            if result.get("session"):
                st.session_state.user = result["user"]
                st.success("✅ Logged in successfully")
            else:
                st.error("❌ Login failed")
    else:
        if st.button("Sign Up"):
            result = supabase.auth.sign_up({"email": email, "password": password})
            if result.get("user"):
                st.success("✅ Account created. Please verify your email.")
            else:
                st.error("❌ Signup failed")
    if "user" not in st.session_state:
        st.stop()