# Landing page placeholder
import streamlit as st
st.title("Welcome to AI Data Assistant")
st.markdown("Chat with your data using AI. Upload CSV, Excel, or JSON and ask questions!")