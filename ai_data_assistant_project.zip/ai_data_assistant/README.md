# AI Data Assistant

This Streamlit app allows users to chat with uploaded datasets (CSV, Excel, JSON) using AI (OpenAI + LangChain).

Features include:
- User authentication (Supabase)
- File upload and analysis
- Chat history and public sharing
- Gamification (badges, points, streaks)
- Leaderboard

## Setup
1. Create `.env` file with your Supabase and OpenAI keys
2. Run `pip install -r requirements.txt`
3. Start the app with `streamlit run app.py`