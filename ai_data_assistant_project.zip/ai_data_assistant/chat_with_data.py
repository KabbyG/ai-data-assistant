from langchain.agents import create_pandas_dataframe_agent
from langchain.chat_models import ChatOpenAI
from supabase_client import supabase
import os

def chat_with_dataframe(df, query, user_id=None, file_name=None):
    openai_api_key = os.getenv("OPENAI_API_KEY")
    llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0, openai_api_key=openai_api_key)
    agent = create_pandas_dataframe_agent(llm, df, verbose=False)
    response = agent.run(query)
    if user_id:
        supabase.table("chats").insert({
            "user_id": user_id,
            "question": query,
            "answer": response,
            "file_name": file_name
        }).execute()
    return response